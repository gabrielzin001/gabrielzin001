
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Commands!</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Knewave&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap" rel="stylesheet">
</head>

<div>
    <header>
        <h1>Automodv12 Bot Commands!</h1>
        <br>
        <h2> All commnds catgeroy here Commands</h2>
    </header>

    <body>
        <div class="container">
            <div class="box">
                <div class="content">
                    <p>⚫ MODERATION - KICK,SETWELCOME,BAN,MUTE.ETC</p>
                    <br>
                    <p>⚫ IMAGE - SPEED, WASTED,RIP.ETC</p>
                    <br>
                    <p>⚫ GIVEWAY - START,END,.ETC</p>
                    <br>
                    <p>⚫ INFO - BOTINFO ,USERINFO,SERVERINFO,</p>
                    <br>
                    <p>⚫ FUN - MEME,SLAP.ETC</p>
                    <br>
                    <p>⚫ ECONOMY -  WORK ,BUY,GIVE.ETC</p>
                    <br>
                    <p>⚫ A BOT WITH 90+ COMMNDS</p>
                </div>
            </div>
            <div class="box">
                <div class="content">
                    <p>⚫ qkick - Kick user</p>
                    <br>
                    <p>⚫ qban - Bans user</p>
                    <br>
                    <p>⚫ qmute - Mutes user</p>
                    <br>
                    <p>⚫ qunmute - Unmutes user</p>
                    <br>
                    <p>⚫ qticket - Creates support ticket</p>
                    <br>
                    <p>⚫ qclear - Clears messages</p>
                    <br>
                    <p>⚫ qrules - Shows embed with rules</p>
                </div>
            </div>
            <button class="btn"  onclick="location.href='https://automodbot.tk'">Back To Main Page</button>
            <br>
            <h4>Copyright © Recluse Bot 2021</h4>
        </div>
    </body>
</div>

<style>

.container {
    width: 1200px;
    position: relative;
    left: 430px;
}
.container .box {
    position: relative;
    width: 500px;
    height: 600px;
    background: rgb(32, 32, 32);
    float: left;
    margin: 15px;
    border-radius: 10px;
}
.btn {
        margin-left: 350px;
        background-color: rgba(27, 27, 27, 0.815);
        color: rgb(255, 255, 255);
        font-size: 40px;
        transition-duration: 0.5s;
        border: 2px solid white;
        border-radius: 10px;
        font-family: 'Josefin Sans', sans-serif;
        
    }


h1 {
    font-family: 'Fredoka One', cursive;
    font-size: 50px;
    text-align: center;
    color: aqua;
    margin-bottom: 15px;
}

h2 {
    font-family: 'Fredoka One', cursive;
    font-size: 30px;
    color: white;
    margin-left: 537px;
}

body {
    background-color: #42455a;
}

h4 {
    font-family: 'Fredoka One', cursive;
    font-size: 30px;
    color: white;
    margin-left: 375px;
}
p {
    font-family: 'Fredoka One', cursive;
    font-size: 20px;
    color: white;
    margin-left: 15px;
}



</style>

<html>
<html lang="en"></html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>button toggler</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <div id="outer-div">
        <div id="inner-div"></div>
    </div>

    <h1 id="msg">Click To Toggle</h1>
    <script src="script.js"></script>
</body>
</html>
<meta name="color-scheme" content="dark light">
